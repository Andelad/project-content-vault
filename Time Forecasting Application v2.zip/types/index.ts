// Re-export all types from core.ts - single source of truth
export * from './core';

// Legacy re-exports for compatibility
export type { ViewType } from './core';